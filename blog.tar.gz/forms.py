from flask import session
from wtforms import Form,StringField,TextAreaField,PasswordField,validators




# Kullanıcı Kayıt Formu
class RegisterForm(Form):   
    username = StringField("Kullanıcı Adı",validators=[validators.Length(min = 5,max = 35)])
    email = StringField("Email Adresi",validators=[validators.Email(message = "Lütfen Geçerli Bir Email Adresi Girin...")])
    password = PasswordField("Parola:",validators=[validators.DataRequired(message = "Lütfen bir parola belirleyin"),
        validators.EqualTo(fieldname = "confirm",message="Parolanız Uyuşmuyor...")])
    confirm = PasswordField("Parola Doğrula")
# Kullanıcı Kayıt Formu
#login formu
class LoginForm(Form):
    username = StringField("Kullanıcı Adı")
    password = PasswordField("Parola")
#login formu