from blog import app,db

#db sınıfları
class Kullanici(db.Model):
    __tablename__ = 'kullanici'
   
    username = db.Column(db.String(80) , primary_key=True)
    email=db.Column(db.String(80))
    password = db.Column(db.String(255))   
  
   

    def __init__(self, username, email,password):
        self.username = username     
        self.email=email
        self.password = password


#db sınıfları